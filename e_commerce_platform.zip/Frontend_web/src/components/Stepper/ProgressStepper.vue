<template>
  <ol class="flex flex-wrap md:flex-nowrap md:items-center w-full text-sm font-medium text-center text-gray-500 dark:text-gray-400 sm:text-base">
    <li v-for="(item, index) in items" :key="index" :class="getStepClass(item.status)">
      <span class="flex items-center after:content-['/'] sm:after:hidden after:mx-2 after:text-gray-200 dark:after:text-gray-500">
        <svg
          v-if="item.status === StepStatus.currentStep"
          class="w-3.5 h-3.5 sm:w-4 sm:h-4 me-2.5"
          aria-hidden="true"
          xmlns="http://www.w3.org/2000/svg"
          fill="currentColor"
          viewBox="0 0 20 20"
        >
          <path
            d="M10 .5a9.5 9.5 0 1 0 9.5 9.5A9.51 9.51 0 0 0 10 .5Zm3.707 8.207-4 4a1 1 0 0 1-1.414 0l-2-2a1 1 0 0 1 1.414-1.414L9 10.586l3.293-3.293a1 1 0 0 1 1.414 1.414Z"
          />
        </svg>
        <span v-else class="me-2">{{ index + 1 }}</span>
        {{ splitTextBySpace(item.nameItem)[0] }}
        <span v-for="(name, index) in splitTextBySpace(item.nameItem).slice(1)" :key="index" class="hidden sm:inline-flex sm:ms-2">{{ name }}</span>
      </span>
    </li>
  </ol>
</template>
<script lang="ts" setup>
  import type { StepItem } from '@PKG_SRC/types'
  import { StepStatus } from '@PKG_SRC/types/enums/constantFrontend'

  const props = defineProps({
    items: {
      type: Array as () => StepItem[],
      required: true,
      default: () => ({}),
    },
  })

  const splitTextBySpace = (text: string) => {
    return splitText(text)
  }

  const classList = ref<Record<number, string>>({
    [StepStatus.currentStep]:
      "flex md:w-full items-center text-blue-600 dark:text-blue-500 sm:after:content-[''] after:w-full after:h-1 after:border-b after:border-gray-200 after:border-1 after:hidden sm:after:inline-block after:mx-6 xl:after:mx-10 dark:after:border-gray-700",
    [StepStatus.pendingStep]:
      "flex md:w-full items-center after:content-[''] after:w-full after:h-1 after:border-b after:border-gray-200 after:border-1 after:hidden sm:after:inline-block after:mx-6 xl:after:mx-10 dark:after:border-gray-700",
    [StepStatus.finishStep]: 'flex items-center',
  })

  const getStepClass = (status: number) => classList.value[status] || ''
</script>
