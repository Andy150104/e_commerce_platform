﻿using System.ComponentModel.DataAnnotations.Schema;
using client.Models;
using Microsoft.AspNetCore.Identity;

namespace Server.Models;

public class User : IdentityUser
{
    public string? Key { get; set; }
    public string RoleId { get; set; }
    
    [ForeignKey("RoleId")]
    public virtual Role Role { get; set; } = null!;
}